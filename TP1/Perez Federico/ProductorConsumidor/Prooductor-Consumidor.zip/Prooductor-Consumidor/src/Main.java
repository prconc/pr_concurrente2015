
public class Main {

	public static void main(String[] args) 
	{
		Buffer buffer = new Buffer();
		Productor productor = new Productor("Productor",buffer);
		Consumidor consumidor = new Consumidor("Consumidor",buffer);
		Productor productor1 = new Productor("Productor1",buffer);
		Consumidor consumidor1 = new Consumidor("Consumidor1",buffer);

	}

}
